const sr = ScrollReveal({
    origin: "bottom",
    distance: "20px",
    duration: 1000,
  });
  
  ScrollReveal().reveal(".titulo", { delay: 300 });
  ScrollReveal().reveal(".container",  { delay: 400 });
  ScrollReveal().reveal(".container-solucao",  { delay: 400 });
  